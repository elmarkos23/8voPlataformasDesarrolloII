﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LabSemana3
{
  public class Cliente
  {
    public int IdCliente { get; set; }
    public String Nombre { get; set; }
    public String Empresa { get; set; }
    public String Telefono { get; set; }
    public String Mail { get; set; }
  }
}